from typing import ClassVar

from django.conf import settings
from django.contrib import admin
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.forms import UserCreationForm as BaseUserCreationForm
from django.utils.translation import gettext_lazy as _

from users.services.activation import send_activation_email

User = get_user_model()


@admin.action(description="Envoyer un e-mail d’activation du compte")
def send_activation_email_from_admin(modeladmin, request, queryset):
    send_activation_email(request, queryset)


class UserCreationForm(BaseUserCreationForm):
    class Meta:
        model = User
        fields = ("email", "username", "first_name", "last_name")


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = (
        "email",
        "username",
        "first_name",
        "last_name",
        "is_active",
        "is_staff",
        "is_superuser",
    )

    list_filter = ("is_active", "is_staff", "is_superuser")

    # ---------------------------------------------------------
    # Champs de statut
    # ---------------------------------------------------------

    status_fields: ClassVar[list[str]] = [
        "is_active",
        "is_staff",
        "is_superuser",
    ]

    if getattr(settings, "USER_GROUP_DISPLAY", False):
        status_fields.append("groups")

    fieldsets = (
        (
            None,
            {
                "fields": [
                    "first_name",
                    "last_name",
                    "email",
                    "username",
                    "password",
                ]
            },
        ),
        (
            _("Status"),
            {"fields": status_fields},
        ),
    )

    # Actions optionnelles
    actions: ClassVar[list[callable]] = []

    if getattr(settings, "USERS_ENABLE_ACTIVATION_EMAIL", False):
        actions.append(send_activation_email_from_admin)

    add_form = UserCreationForm

    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "email",
                    "username",
                    "first_name",
                    "last_name",
                    "password1",
                    "password2",
                ),
            },
        ),
    )

    search_fields = ("first_name", "username", "last_name", "email")
    ordering = ("first_name", "last_name")
