from django.urls import path, include
from rest_framework import routers
from .views import CustomTokenObtainPairView, ActivationView, ActivationResendView
import djoser

app_name = 'users'

urlpatterns = [

    # --- Overrides d'abord ---                                                    
    path('auth/jwt/create/', CustomTokenObtainPairView.as_view(), name='jwt-create'),
    path("auth/activation/", ActivationView.as_view(), name="activation-custom"),
    path("auth/resend_activation/", ActivationResendView.as_view(), name="resend-activation-custom"),

    # --- Ensuite Djoser ---                                                    
    path('auth/', include('djoser.urls')),                     
    #path('auth/', include('djoser.urls.jwt')),
    path(r'^auth/', include('djoser.urls.jwt')),
]
