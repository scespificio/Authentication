from django.urls import path, include
from rest_framework import routers
from .views import CustomTokenObtainPairView

app_name = 'users'

urlpatterns = [
    path('auth/jwt/create/', CustomTokenObtainPairView.as_view(), name='jwt-create')
]
