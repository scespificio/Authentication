from django.urls import include, path

from .views import ActivationResendView, ActivationView, CustomTokenObtainPairView

app_name = "users"

urlpatterns = [
    # --- Overrides d'abord ---
    path("auth/jwt/create/", CustomTokenObtainPairView.as_view(), name="jwt-create"),
    path("auth/activation/", ActivationView.as_view(), name="activation-custom"),
    path(
        "auth/resend_activation/",
        ActivationResendView.as_view(),
        name="resend-activation-custom",
    ),
    # --- Ensuite Djoser ---
    path("auth/", include("djoser.urls")),
    path("auth/", include("djoser.urls.jwt")),
]
