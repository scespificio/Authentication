import logging
from typing import ClassVar

from django.conf import settings
from django.contrib.auth.tokens import default_token_generator
from django.core.cache import cache
from djoser.serializers import ActivationSerializer as DJActivationSerializer
from djoser.serializers import SendEmailResetSerializer
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.permissions import AllowAny, BasePermission
from rest_framework.response import Response
from rest_framework.views import APIView

from .serializers import CustomTokenObtainPairSerializer

logger = logging.getLogger(__name__)

from urllib.parse import urljoin

from django.contrib.auth import get_user_model
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from djoser.utils import decode_uid
from rest_framework.throttling import ScopedRateThrottle, UserRateThrottle
from rest_framework_simplejwt.views import TokenObtainPairView

# from users.services.activation import send_activation_email
from users.emails import ActivationEmail, PasswordResetEmail


@api_view(["GET"])
def home(request):
    return Response({"message": "Hello, world. You're at the home page."})


class CustomTokenObtainPairView(TokenObtainPairView):
    throttle_scope = "user"
    throttle_classes: ClassVar[list[type]] = [
        ScopedRateThrottle,
        UserRateThrottle,
    ]  # ajoute le throttling pour cet endpoint et par IP.
    serializer_class = CustomTokenObtainPairSerializer


User = get_user_model()


def get_user_from_uid_token(uid: str, token: str):
    """
    Retourne (user, is_valid)
    - user : instance User ou None
    - is_valid : True si le token correspond et n'est pas expiré
    """

    if not uid or not token:
        return None, False

    try:
        user_id = decode_uid(uid)
        user = User.objects.get(pk=user_id)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        return None, False

    # Vérifie la validité du token
    is_valid = default_token_generator.check_token(user, token)
    return user, is_valid


class ActivationView(APIView):
    permission_classes: ClassVar[list[type[BasePermission]]] = [
        AllowAny
    ]  # l’activation est anonyme
    token_generator = default_token_generator  # <<< important

    def post(self, request):
        uid = request.data.get("uid")
        token = request.data.get("token")
        user, _ = get_user_from_uid_token(uid, token)

        if not request.data.get("uid") or not request.data.get("token"):
            email = request.data.get("email")
            user = User.objects.filter(email=email).first()

            if not user:
                return Response(
                    {"detail": "User not found"}, status=status.HTTP_404_NOT_FOUND
                )
            if user.is_active:
                return Response(
                    {"detail": "Compte déjà activé"}, status=status.HTTP_403_FORBIDDEN
                )
            s = SendEmailResetSerializer(
                data={"email": email}, context={"request": request}
            )

        s = DJActivationSerializer(
            data={"uid": uid, "token": token},
            context={"request": request, "view": self},
        )
        s.is_valid(raise_exception=True)
        user.is_active = True
        user.save(update_fields=["is_active"])

        if not cache.add(f"password:reset-sent:view:{user.pk}", "1", timeout=60 * 1):
            logger.info("[password] skip duplicate (view) for %s", user.email)
        else:
            token = default_token_generator.make_token(user)
            # Contexte attendu par ta classe ActivationEmail
            ctx = {
                "user": user,
                "uid": uid,
                "token": token,
                # Djoser fournit normalement url via ACTIVATION_URL,
                # mais si tu veux, construis-la côté front à partir de ces deux valeurs.
                "frontend_url": settings.FRONTEND_BASE_URL,
                "site_name": getattr(settings, "EMAIL_FRONTEND_SITE_NAME", None)
                or "Site",
                "domain": settings.DJOSER.get("DOMAIN", ""),
                "request": request,
            }
            print("Activation view ctx:", ctx)
            PasswordResetEmail(context=ctx).send(to=user.email)

        return Response(
            {"detail": "Activation réussie."},
            status=status.HTTP_200_OK,
        )


class ActivationResendView(APIView):
    permission_classes: ClassVar[list[type[BasePermission]]] = [
        AllowAny
    ]  # l’activation est anonyme

    def post(self, request):
        email = request.data.get("email")
        if not email:
            return Response(
                {"detail": "Email requis."}, status=status.HTTP_400_BAD_REQUEST
            )
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response(
                {"detail": "Aucun utilisateur trouvé avec cet email."},
                status=status.HTTP_404_NOT_FOUND,
            )
        if user.is_active:
            return Response(
                {"detail": "Compte déjà activé."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        uid = urlsafe_base64_encode(force_bytes(user.pk))
        token = default_token_generator.make_token(user)

        # Contexte attendu par ta classe ActivationEmail
        ctx = {
            "user": user,
            "uid": uid,
            "token": token,
            # Djoser fournit normalement url via ACTIVATION_URL,
            # mais si tu veux, construis-la côté front à partir de ces deux valeurs.
            "activation_url": urljoin(
                settings.FRONTEND_BASE_URL, f"/activate/{uid}/{token}"
            ),
            "site_name": getattr(settings, "EMAIL_FRONTEND_SITE_NAME", None) or "Site",
            "domain": request.get_host(),
            "request": request,
        }
        ActivationEmail(context=ctx).send(to=user.email)
        return Response(
            {"detail": "Lien d'activation réinitialisé."},
            status=status.HTTP_204_NO_CONTENT,
        )
