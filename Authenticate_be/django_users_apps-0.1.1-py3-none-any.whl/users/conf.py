from django.conf import settings

LOGIN_FIELD = getattr(settings, "USERS_LOGIN_FIELD", "email") # Login field defaults to email when unspecified.