from urllib.parse import urljoin

from django.conf import settings
from django.contrib.auth.tokens import default_token_generator
from django.utils.encoding import force_str
from djoser.email import (
    ActivationEmail as BaseActivationEmail,
)
from djoser.email import (
    PasswordResetEmail as BasePasswordResetEmail,
)
from djoser.utils import encode_uid
from users.tasks import send_djoser_email


def _build_base_url(protocol: str | None, domain: str | None) -> str:
    safe_protocol = protocol or settings.DJOSER.get("PROTOCOL") or "https"
    safe_domain = domain or settings.DJOSER.get("DOMAIN") or "localhost"
    return f"{safe_protocol}://{safe_domain}/"


def _build_media_url(base_url: str, relative_path: str) -> str:
    media_prefix = settings.MEDIA_URL.lstrip("/")
    return urljoin(base_url, f"{media_prefix}{relative_path}")


class ActivationEmail(BaseActivationEmail):
    # def get_connection(self, fail_silently=False, **kwargs):
    #    # force fail_silently=False quoiqu'il arrive
    #    return super().get_connection(fail_silently=False, **kwargs)

    def send(self, to):
        """
        Ne passe à Celery que des primitives JSON (pas d'objet user, pas de request).
        """
        ctx = dict(self.get_context_data() or {})
        user = ctx.get("user")

        uid = ctx.get("uid") or encode_uid(user.pk)
        token = ctx.get("token") or default_token_generator.make_token(user)

        base_be = _build_base_url("https", ctx.get("domain").removeprefix("https://"))
        print(f"prefix : {base_be}")

        payload = {
            "kind": "activation",
            "to": to if isinstance(to, (list, tuple)) else [to],
            "user_id": user.pk,
            "uid": force_str(uid),
            "token": force_str(token),
            "activation_url": ctx.get("activation_url"),
            "site_name": getattr(settings, "DJANGO_APP_NAME", ""),
            "domain": ctx.get("domain"),
            "protocol": ctx.get("protocol"),
        }
        send_djoser_email.delay(payload)
        print("e-mail d'activation envoyé")


class PasswordResetEmail(BasePasswordResetEmail):
    """
    Email de réinitialisation de mot de passe personnalisé :
    - Envoie un payload complet à la tâche Celery.
    """

    def send(self, to):
        # Récupère le contexte enrichi (fusionné)
        ctx = self.get_context_data()
        user = ctx.get("user")
        base_be = _build_base_url(ctx.get("protocol"), ctx.get("domain"))
        print(f"prefix : {base_be}")

        # Prépare le payload envoyé à ton worker Celery
        payload = {
            "kind": "password_reset",
            "to": to if isinstance(to, (list, tuple)) else [to],
            "user_id": user.pk,
            "uid": force_str(ctx.get("uid") or ""),
            "token": force_str(ctx.get("token") or ""),
            "frontend_url": ctx.get("frontend_url"),
            "site_name": getattr(settings, "DJANGO_APP_NAME", ""),
            "protocol": settings.DJOSER.get("PROTOCOL"),
            "domain": settings.DJOSER.get("DOMAIN"),
            "reset_url": ctx.get("reset_url") or ctx.get("url"),
        }

        send_djoser_email.delay(payload)

        fe_url = ctx.get("reset_url") or ctx.get("url")
        print(type(fe_url))
        print(fe_url[5:])
