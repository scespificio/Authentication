from django.urls import path, include
from rest_framework import routers
from .views import CustomTokenObtainPairView, ConfigDetailView

router = routers.DefaultRouter()
router.register(r'config', ConfigDetailView, basename='config')

app_name = 'users'

urlpatterns = [
    path('auth/jwt/create/', CustomTokenObtainPairView.as_view(), name='jwt-create')
] + router.urls
