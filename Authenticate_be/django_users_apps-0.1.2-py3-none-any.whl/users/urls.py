from django.conf import settings
from django.urls import include, path
from rest_framework import routers  # noqa: F401

from .views import (
    ActivationResendView,
    ActivationView,
    CustomTokenObtainPairView,
    SSOTokenExchangeView,
)

app_name = "users"

urlpatterns = [
    # --- Overrides d'abord ---
    path("auth/jwt/create/", CustomTokenObtainPairView.as_view(), name="jwt-create"),
    path("auth/activation/", ActivationView.as_view(), name="activation-custom"),
    path(
        "auth/resend_activation/",
        ActivationResendView.as_view(),
        name="resend-activation-custom",
    ),
    path("auth/jwt/exchange/", SSOTokenExchangeView.as_view(), name="jwt-sso-exchange"),
    # --- Ensuite Djoser ---
    path("auth/", include("djoser.urls")),
    path("auth/", include("djoser.urls.jwt")),
]

if getattr(settings, "USERS_ENABLE_SSO", False):
    urlpatterns += [
        # --- Mozilla OIDC pour SSO ---
        path("oidc/", include("mozilla_django_oidc.urls")),
    ]
