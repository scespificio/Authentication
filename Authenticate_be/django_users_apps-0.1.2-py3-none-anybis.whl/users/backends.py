from mozilla_django_oidc.auth import OIDCAuthenticationBackend


class MyOIDCBackend(OIDCAuthenticationBackend):
    def filter_users_by_claims(self, claims):
        # How to find an EXISTING user matching this SSO identity.
        email = claims.get("email")
        username = claims.get("preferred_username")
        if not email:
            return self.UserModel.objects.none()
        return self.UserModel.objects.filter(email=email, username=username)

    def create_user(self, claims):
        email = claims.get("email")
        username = claims.get("preferred_username")
        print("[INFO] Récupération des claims", email, username)
        print("[INFO] Création d'utilisateur...")
        user = self.UserModel.objects.create_user(email=email, username=username)
        user.sso_subject = claims.get("sub", "")
        user.sso_provider = claims.get("iss", "")
        user.first_name = claims.get("given_name", "")
        user.last_name = claims.get("family_name", "")
        user.save()
        return user

    def update_user(
        self, user, claims
    ):  # overwrites on every login to keep IdP synchronized with the database
        user.email = claims.get("email")
        user.username = claims.get("preferred_username")
        user.first_name = claims.get("given_name", "")
        user.last_name = claims.get("family_name", "")
        user.save()
        return user

    """def verify_claims(self, claims): # Eventual integrity checks to reject user during SSO authentication (prevents user creation)
        verified = super(MyOIDCAB, self).verify_claims(claims)
        is_admin = 'admin' in claims.get('group', [])
        return verified and is_admin"""
