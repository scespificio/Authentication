from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("users", "0002_user_sso_provider_user_sso_subject_and_more"),
    ]

    operations = [
        migrations.AlterField(
            model_name="user",
            name="sso_provider",
            field=models.CharField(blank=True, max_length=50, null=True),
        ),
    ]
