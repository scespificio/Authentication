from typing import ClassVar  # noqa: EXE002

from django.conf import settings
from django.contrib import admin
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.forms import UserCreationForm as BaseUserCreationForm
from django.utils.translation import gettext_lazy as _

from .services.activation import send_activation_email

User = get_user_model()
from .models import Domain, UserIAM


@admin.action(description="Envoyer un e-mail d’activation du compte")
def send_activation_email_from_admin(modeladmin, request, queryset):
    send_activation_email(request, queryset)


class UserCreationForm(BaseUserCreationForm):
    class Meta:
        model = User
        fields = ("email", "username", "first_name", "last_name")


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = (
        "email",
        "username",
        "first_name",
        "last_name",
        "is_active",
        "is_staff",
        "is_superuser",
    )

    list_filter = ("is_active", "is_staff", "is_superuser", "sso_provider")

    # ---------------------------------------------------------
    # Champs de statut
    # ---------------------------------------------------------

    status_fields: ClassVar[list[str]] = [
        "is_active",
        "is_staff",
        "is_superuser",
    ]

    if getattr(settings, "USER_GROUP_DISPLAY", False):
        status_fields.append("groups")

    fieldsets = (
        (
            None,
            {
                "fields": [
                    "first_name",
                    "last_name",
                    "email",
                    "username",
                    "sso_provider",
                    "sso_subject",
                    "password",
                ]
            },
        ),
        (
            _("Status"),
            {"fields": status_fields},
        ),
    )
    exclude = (
        "sso_provider",
        "sso_subject",
    )
    readonly_fields = (
        "sso_provider",
        "sso_subject",
    )

    # Actions optionnelles
    actions = []

    if getattr(settings, "USERS_ENABLE_ACTIVATION_EMAIL", False):
        actions.append(send_activation_email_from_admin)

    add_form = UserCreationForm

    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "email",
                    "username",
                    "sso_provider",
                    "sso_subject",
                    "first_name",
                    "last_name",
                    "password1",
                    "password2",
                ),
            },
        ),
    )

    search_fields = ("first_name", "username", "last_name", "email")
    ordering = ("first_name", "last_name")


@admin.register(UserIAM)
class UserIAMAdmin(admin.ModelAdmin):
    list_display = ("user_email", "user_username")
    ordering = ("-id",)
    filter_horizontal = ("domaines",)

    @admin.display(description="Email", ordering="user__email")
    def user_email(self, obj):
        return obj.user.email

    @admin.display(description="Utilisateur", ordering="user__username")
    def user_username(self, obj):
        return obj.user.username


@admin.register(Domain)
class DomainAdmin(admin.ModelAdmin):
    list_display = ("nom", "url")
    ordering = ("-id",)
    search_fields = ("nom", "url")
