from django.apps import AppConfig  # noqa: EXE002


class UsersConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "users"

    def ready(self):
        print("[apps.ready] user signals loaded", flush=True)  # trace visible au boot
