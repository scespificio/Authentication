from typing import ClassVar  # noqa: EXE002

from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models
from django.utils.translation import gettext_lazy as _


class UserManager(BaseUserManager):
    """Manager personnalisé pour User avec email comme identifiant"""

    def create_user(self, email, username, password=None, **extra_fields):
        if not email:
            raise ValueError(_("L'adresse email doit être renseignée"))
        if not username:
            raise ValueError(_("Le nom d'utilisateur doit être renseignée"))
        email = self.normalize_email(email)
        user = self.model(email=email, username=username, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, username, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)

        if extra_fields.get("is_staff") is not True:
            raise ValueError(_("Le superuser doit avoir is_staff=True."))
        if extra_fields.get("is_superuser") is not True:
            raise ValueError(_("Le superuser doit avoir is_superuser=True."))

        return self.create_user(email, username, password, **extra_fields)


# Create your models here.
class User(AbstractUser):
    username = models.CharField(_("Nom d'utilisateur"), unique=True, max_length=64)
    email = models.EmailField(_("Adresse e-mail"), unique=True)
    sso_subject = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        unique=True,
    )
    sso_provider = models.CharField(max_length=50, null=True, blank=True)
    is_staff = models.BooleanField(
        _("Membre"),
        default=False,
        help_text=_(
            "Indique si l'utilisateur peut se connecter au site d’administration de la plateforme."
        ),
    )
    is_superuser = models.BooleanField(
        _("Administrateur Plateforme"),
        default=False,
        help_text=_("Indique que cet utilisateur a tous les droits"),
    )

    USERNAME_FIELD = "email"  # champ utilisé pour l'authentification
    REQUIRED_FIELDS: ClassVar[list[str]] = ["username"]

    objects = UserManager()  # on attache le manager custom

    def __str__(self):
        return self.email

    class Meta:
        verbose_name = _("Utilisateur")
        verbose_name_plural = _("Utilisateur")


class Domain(models.Model):
    nom = models.CharField(max_length=100)
    url = models.CharField(
        unique=True,
        max_length=100,
        help_text="Renseigner sous la forme DOMAINE/SOUS-DOMAINE sans '/' à la fin.",
    )

    def __str__(self) -> str:
        return self.nom

    class Meta:
        verbose_name = "Domaine"
        verbose_name_plural = "Domaines"


class UserIAM(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="authenticate_profile",
    )
    # nom = models.CharField(max_length=100)
    domaines = models.ManyToManyField(
        Domain,
        blank=True,
        related_name="droits",
        verbose_name="Domaines autorisés",
    )

    def __str__(self) -> str:
        return str(self.user)

    class Meta:
        verbose_name = "Droit Utilisateur"
        verbose_name_plural = "Droits Utilisateur"


class EmailTemplate(models.Model):
    name = models.CharField(max_length=100)
    description = models.CharField(max_length=200, blank=True)
    title = models.CharField(max_length=200)
    content = models.TextField()
    footer = models.TextField(blank=True)

    def __str__(self) -> str:
        return self.name

    class Meta:
        verbose_name = "Modèle d’email"
        verbose_name_plural = "Modèles d’email"
