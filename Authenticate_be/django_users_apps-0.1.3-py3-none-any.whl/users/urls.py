from django.conf import settings  # noqa: EXE002
from django.urls import include, path
from rest_framework import routers  # noqa: F401

from . import views

app_name = "users"

urlpatterns = [
    path("profil/", views.ProfileView.as_view(), name="profil"),
    path("profil/me/", views.ProfileViewDetail.as_view(), name="profil-me"),
    path("domaine/", views.DomainView.as_view(), name="domaine"),
    path("domaine/me/", views.DomainUserView.as_view(), name="domaine-me"),
    # --- Overrides d'abord ---
    path("auth/jwt/check/", views.CheckCookieView.as_view(), name="check-jwt-cookie"),
    path(
        "auth/jwt/create/", views.CustomTokenObtainPairView.as_view(), name="jwt-create"
    ),
    path(
        "auth/jwt/exchange/",
        views.SSOTokenExchangeView.as_view(),
        name="jwt-sso-exchange",
    ),
    path("auth/activation/", views.ActivationView.as_view(), name="activation-custom"),
    path(
        "auth/resend_activation/",
        views.ActivationResendView.as_view(),
        name="resend-activation-custom",
    ),
    path("auth/authorize/", views.AuthorizeView.as_view(), name="autorisation"),
    # --- Ensuite Djoser ---
    path("auth/", include("djoser.urls")),
    path("auth/", include("djoser.urls.jwt")),
]

if getattr(settings, "USERS_ENABLE_SSO", False):
    urlpatterns += [
        # --- Mozilla OIDC pour SSO ---
        path("oidc/", include("mozilla_django_oidc.urls")),
    ]
