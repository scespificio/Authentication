from django.db import IntegrityError, transaction  # noqa: EXE002
from mozilla_django_oidc.auth import OIDCAuthenticationBackend
from rest_framework.exceptions import ValidationError


class MyOIDCBackend(OIDCAuthenticationBackend):
    def filter_users_by_claims(self, claims):
        # How to find an EXISTING user matching this SSO identity.
        sub = claims.get("sub", "")
        email = claims.get("email")

        if sub:  # Stage 1 : verify if the SSO-originated user has already logged in.
            match = self.UserModel.objects.filter(sso_subject=sub)
            if match.exists():
                return match

        if email:  # Stage 2 : verify if the new SSO-originated user corresponds to a native user from the database.
            match = self.UserModel.objects.filter(email__iexact=email)
            if match.exists():
                return match

        return self.UserModel.objects.none()  # Stage 3 : genuinely new user

    def create_user(self, claims):

        try:
            with transaction.atomic():
                email = claims.get("email")
                username = claims.get(
                    "preferred_username"
                )  # ATTENTION : peut-être pas toujours présent dans l'IdP
                username = self._unique_username(username)

                user = self.UserModel.objects.create_user(
                    email=email, username=username
                )
                user.sso_subject = claims.get("sub", "")
                user.sso_provider = claims.get("iss", "")
                user.first_name = claims.get("given_name", "")
                user.last_name = claims.get("family_name", "")
                user.save()
                return user
        except IntegrityError:
            raise ValidationError("Cet utilisateur existe déjà.")

    def update_user(
        self, user, claims
    ):  # overwrites on every login to keep IdP synchronized with the database
        # si l'utilisateur existe déjà dans la BDD, on préserve l'username existant
        user.sso_subject = claims.get("sub", "")
        user.sso_provider = claims.get("iss", "")
        user.first_name = claims.get("given_name", "")
        user.last_name = claims.get("family_name", "")
        user.save()
        return user

    def _unique_username(self, base_username):
        # Override the default behavior to avoid duplicate usernames conflicts between SSO and native users
        i = 0
        username = base_username
        while self.UserModel.objects.filter(username=username).exists():
            i += 1
            username = f"{base_username}_{i}"
        return username

    """def verify_claims(self, claims): # Eventual integrity checks to reject user during SSO authentication (prevents user creation)
        verified = super(MyOIDCAB, self).verify_claims(claims)
        is_admin = 'admin' in claims.get('group', [])
        return verified and is_admin"""
