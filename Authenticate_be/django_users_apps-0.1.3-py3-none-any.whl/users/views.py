import logging  # noqa: EXE002
import os

from django.conf import settings
from django.contrib.auth.tokens import default_token_generator
from django.core.cache import cache
from djoser.serializers import (
    ActivationSerializer as DJActivationSerializer,
)
from djoser.serializers import (
    SendEmailResetSerializer,
)
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.views import APIView

from .serializers import CustomTokenObtainPairSerializer

logger = logging.getLogger(__name__)

from typing import ClassVar
from urllib.parse import urljoin

from django.contrib.auth import get_user_model
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from djoser.utils import decode_uid
from rest_framework.authentication import SessionAuthentication
from rest_framework.generics import GenericAPIView
from rest_framework.permissions import AllowAny, BasePermission, IsAuthenticated
from rest_framework.throttling import ScopedRateThrottle, UserRateThrottle
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.tokens import AccessToken, RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView

from .emails import ActivationEmail, PasswordResetEmail
from .models import Domain, User, UserIAM
from .serializers import DomainSerializer, ProfileSerializer
from .services.authorization import user_has_domain_access

DOMAIN_NAME = os.getenv("DOMAIN_NAME")


@api_view(["GET"])
def home(request):
    return Response({"message": "Hello, world. You're at the home page."})


class CustomTokenObtainPairView(TokenObtainPairView):
    throttle_scope = "user"
    throttle_classes = [
        ScopedRateThrottle,
        UserRateThrottle,
    ]  # ajoute le throttling pour cet endpoint et par IP.
    serializer_class = CustomTokenObtainPairSerializer


User = get_user_model()  # noqa: F811


def get_user_from_uid_token(uid: str, token: str):
    """
    Retourne (user, is_valid)
    - user : instance User ou None
    - is_valid : True si le token correspond et n'est pas expiré
    """

    if not uid or not token:
        return None, False

    try:
        user_id = decode_uid(uid)
        user = User.objects.get(pk=user_id)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        return None, False

    # Vérifie la validité du token
    is_valid = default_token_generator.check_token(user, token)
    return user, is_valid


class SSOTokenExchangeView(
    APIView
):  # Echange un cookie de session Django contre un JWT (authentification SSO)
    authentication_classes = [SessionAuthentication]
    permission_classes: ClassVar[list[type[BasePermission]]] = [IsAuthenticated]

    def post(self, request):
        refresh = RefreshToken.for_user(request.user)
        return Response(
            {
                "access": str(refresh.access_token),
                "refresh": str(refresh),
            }
        )


class ActivationView(APIView):
    permission_classes: ClassVar[list[type[BasePermission]]] = [
        AllowAny
    ]  # l’activation est anonyme
    token_generator = default_token_generator  # <<< important

    def post(self, request):
        uid = request.data.get("uid")
        token = request.data.get("token")
        user, _ = get_user_from_uid_token(uid, token)

        if not request.data.get("uid") or not request.data.get("token"):
            email = request.data.get("email")
            user = User.objects.filter(email=email).first()

            if not user:
                return Response(
                    {"detail": "User not found"}, status=status.HTTP_404_NOT_FOUND
                )
            if user.is_active:
                return Response(
                    {"detail": "Compte déjà activé"}, status=status.HTTP_403_FORBIDDEN
                )
            s = SendEmailResetSerializer(
                data={"email": email}, context={"request": request}
            )

        s = DJActivationSerializer(
            data={"uid": uid, "token": token},
            context={"request": request, "view": self},
        )
        s.is_valid(raise_exception=True)
        user.is_active = True
        user.save(update_fields=["is_active"])

        if not cache.add(f"password:reset-sent:view:{user.pk}", "1", timeout=60 * 1):
            logger.info("[password] skip duplicate (view) for %s", user.email)
        else:
            token = default_token_generator.make_token(user)
            # Contexte attendu par ta classe ActivationEmail
            ctx = {
                "user": user,
                "uid": uid,
                "token": token,
                # Djoser fournit normalement url via ACTIVATION_URL,
                # mais si tu veux, construis-la côté front à partir de ces deux valeurs.
                "frontend_url": settings.FRONTEND_BASE_URL,
                "site_name": getattr(settings, "EMAIL_FRONTEND_SITE_NAME", None)
                or "Site",
                "domain": settings.DJOSER.get("DOMAIN", ""),
                "request": request,
            }
            print("Activation view ctx:", ctx)
            PasswordResetEmail(context=ctx).send(to=user.email)

        return Response(
            {"detail": "Activation réussie."},
            status=status.HTTP_200_OK,
        )


class ActivationResendView(APIView):
    permission_classes: ClassVar[list[type[BasePermission]]] = [
        AllowAny
    ]  # l’activation est anonyme

    def post(self, request):
        email = request.data.get("email")
        if not email:
            return Response(
                {"detail": "Email requis."}, status=status.HTTP_400_BAD_REQUEST
            )
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response(
                {"detail": "Aucun utilisateur trouvé avec cet email."},
                status=status.HTTP_404_NOT_FOUND,
            )
        if user.is_active:
            return Response(
                {"detail": "Compte déjà activé."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        uid = urlsafe_base64_encode(force_bytes(user.pk))
        token = default_token_generator.make_token(user)

        # Contexte attendu par ta classe ActivationEmail
        ctx = {
            "user": user,
            "uid": uid,
            "token": token,
            # Djoser fournit normalement url via ACTIVATION_URL,
            # mais si tu veux, construis-la côté front à partir de ces deux valeurs.
            "activation_url": urljoin(
                settings.FRONTEND_BASE_URL, f"/activate/{uid}/{token}"
            ),
            "site_name": getattr(settings, "EMAIL_FRONTEND_SITE_NAME", None) or "Site",
            "domain": request.get_host(),
            "request": request,
        }
        ActivationEmail(context=ctx).send(to=user.email)
        return Response(
            {"detail": "Lien d'activation réinitialisé."},
            status=status.HTTP_204_NO_CONTENT,
        )


class ProfileView(GenericAPIView):  # GET all
    serializer_class = ProfileSerializer
    queryset = UserIAM.objects.all()

    def get(self, request):
        obj = self.get_queryset()
        return Response(
            self.get_serializer(obj, many=True).data, status=status.HTTP_200_OK
        )


class ProfileViewDetail(GenericAPIView):  # GET one
    serializer_class = ProfileSerializer
    queryset = UserIAM.objects.all()

    def get(self, request):
        obj = self.get_queryset().filter(user=request.user)
        return Response(
            self.get_serializer(obj, many=True).data, status=status.HTTP_200_OK
        )


class DomainView(GenericAPIView):  # GET all (TEMPORAIRE)
    serializer_class = DomainSerializer
    queryset = Domain.objects.all()

    def get(self, request):
        obj = self.get_queryset()
        return Response(
            self.get_serializer(obj, many=True).data, status=status.HTTP_200_OK
        )


class DomainUserView(GenericAPIView):  # GET all domaines associés avec l'utilisateur
    serializer_class = DomainSerializer
    queryset = Domain.objects.all()

    def get(self, request):
        obj = self.get_queryset().filter(droits__user=request.user)
        return Response(
            self.get_serializer(obj, many=True).data, status=status.HTTP_200_OK
        )


class AuthorizeView(GenericAPIView):  # GET response
    def get(self, request):

        if (
            not "X-Requested-Host" in request.headers
        ):  # Aucun paramètre = tentative de connexion à la page d'accueil.
            is_authorized = True
            token = request.headers.get("Authorization")[4:]
            # return Response({"error": "Domain invalide. Veuillez vérifier vos headers"}, status=status.HTTP_400_BAD_REQUEST)

        else:  # Paramètre existant = tentative de connexion à une URL précise.
            host = request.headers.get(
                "X-Requested-Host"
            )  # Lecture du domaine d'origine depuis les headers
            token = request.headers.get("Authorization")[4:]
            is_authorized, status_code = user_has_domain_access(request.user, host)

        if is_authorized:
            response = Response(
                {"message": "Autorisation réussie avec succès."},
                status=status.HTTP_200_OK,
            )
            response.set_cookie(
                "session_auth",
                value=token,  # Characters excluding the "JWT " at the beginning of the Authorization header
                httponly=True,
                secure=True,
                samesite="Lax",
                domain=DOMAIN_NAME,
                path="/",
                max_age=3600,
            )
            return response

        elif not is_authorized and status_code == 403:
            return Response(
                {"error": f"L'autorisation a échoué : vous n'avez pas accès à {host}"},
                status=status.HTTP_403_FORBIDDEN,
            )

        elif not is_authorized and status_code == 404:
            return Response(
                {"error": f"Le domaine {host} est introuvable."},
                status=status.HTTP_404_NOT_FOUND,
            )
        else:
            return Response(
                {"error": "Requête invalide."}, status=status.HTTP_400_BAD_REQUEST
            )


class CheckCookieView(GenericAPIView):
    authentication_classes = []  # Allows connection without a JWT, from other websites
    permission_classes: ClassVar[list[type[BasePermission]]] = [AllowAny]

    def get(self, request):
        if not "X-Request-URI" in request.headers:
            return Response(
                {"error": "Domain invalide. Veuillez vérifier vos headers."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if not "session_auth" in request.COOKIES:
            return Response(
                {
                    "error": "Le cookie session_auth est introuvable. Veuillez vérifier vos cookies"
                },
                status=status.HTTP_401_UNAUTHORIZED,
            )

        token = request.COOKIES.get("session_auth")
        host = request.headers.get("X-Request-URI")

        try:
            decoded = AccessToken(
                token
            )  # This will raise an exception if the token is invalid.
            decoded = decoded.payload
            user_id = decoded.get("user_id")
            user = User.objects.filter(id=user_id).first()

            is_authorized, status_code = user_has_domain_access(user, host)

        except TokenError:
            return Response(
                {"error": "Invalid token."}, status=status.HTTP_401_UNAUTHORIZED
            )

        if is_authorized:
            return Response({"message": "Success!"}, status=status.HTTP_200_OK)

        elif not is_authorized and status_code == 403:
            return Response(
                {"error": f"L'autorisation a échoué : vous n'avez pas accès à {host}"},
                status=status.HTTP_403_FORBIDDEN,
            )

        elif not is_authorized and status_code == 404:
            return Response(
                {"error": f"Le domaine {host} est introuvable."},
                status=status.HTTP_404_NOT_FOUND,
            )

        else:
            return Response(
                {"error": "Requête invalide."}, status=status.HTTP_400_BAD_REQUEST
            )
