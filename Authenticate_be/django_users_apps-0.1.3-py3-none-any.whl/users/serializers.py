from typing import ClassVar  # noqa: EXE002

from django.conf import settings
from djoser.serializers import UserCreateSerializer as BaseUserCreateSerializer
from djoser.serializers import UserSerializer as BaseUserSerializer
from rest_framework.exceptions import ValidationError
from rest_framework.serializers import ModelSerializer, ReadOnlyField
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from .models import Domain, User, UserIAM

LOGIN_FIELD = getattr(
    settings, "USERS_LOGIN_FIELD", "email"
)  # Login field defaults to email when unspecified.


def resolve_users(login):

    if LOGIN_FIELD == "username":
        try:
            user = User.objects.get(username=login)
            return user
        except User.DoesNotExist:
            return None

    elif LOGIN_FIELD == "email":
        try:
            user = User.objects.get(email=login)
            return user
        except User.DoesNotExist:
            return None

    elif LOGIN_FIELD == "both":
        try:
            user = User.objects.get(email=login)
            return user
        except User.DoesNotExist:
            pass

        try:
            user = User.objects.get(username=login)
            return user
        except User.DoesNotExist:
            return None
    else:
        raise ValueError(
            "Paramètre LOGIN_FIELD invalide : ni 'username', ni 'email', ni 'both'."
        )


class UserCreateSerializer(BaseUserCreateSerializer):
    class Meta(BaseUserCreateSerializer.Meta):
        fields = (
            "email",
            "username",
            "password",
            "first_name",
            "last_name",
            "sso_provider",
            "sso_subject",
        )


class UserSerializer(BaseUserSerializer):
    class Meta(BaseUserSerializer.Meta):
        fields = (
            "email",
            "username",
            "first_name",
            "last_name",
            "sso_provider",
            "sso_subject",
        )


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        return super().get_token(user)

    def validate(self, attrs):

        login = attrs.get("email")
        password = attrs.get("password")

        user = resolve_users(
            login
        )  # from LOGIN_FIELD and 'login' (username or email) resolves a user object.

        if user is None:
            raise ValidationError("Cet utilisateur n'existe pas.")

        self.user = user
        # return super().get_token(user)

        if not user.check_password(password):  # Manual password check
            raise ValidationError("Mot de passe incorrect")

        refresh_token = self.get_token(user)
        access_token = refresh_token.access_token

        data = {"refresh": refresh_token, "access": access_token}

        # original validate call, unused : throttling isn't enforced automatically, and no signals are produced on login success or failure.
        # data = super().validate(attrs)  # {'refresh': '...', 'access': '...'}

        # Sérialise l'user + insère les tokens via le context
        user_data = UserSerializer(
            self.user, context={"request": self.context.get("request"), "tokens": data}
        ).data

        return {
            **user_data,
            "access_token": str(data.get("access")),
            "refresh_token": str(data.get("refresh")),
        }


class ProfileSerializer(ModelSerializer):
    utilisateur_nom = ReadOnlyField(source="User.email")

    class Meta:
        model = UserIAM
        fields: ClassVar[list[str]] = ["utilisateur_nom", "nom"]

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation["domaines"] = [
            domaines.nom for domaines in instance.domaines.all()
        ]

        return representation


class DomainSerializer(ModelSerializer):
    class Meta:
        model = Domain
        fields = "__all__"
