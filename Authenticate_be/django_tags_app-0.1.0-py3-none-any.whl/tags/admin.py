from django.contrib import admin
from django.contrib.contenttypes.admin import GenericTabularInline
from .models import Tag, TaggedItem

class TagsInline(GenericTabularInline):
    model = TaggedItem
    extra = 1
    rautocomplete_fields = ["tag"]

@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    search_fields = ['label']
